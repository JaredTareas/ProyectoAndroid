package com.example.loginapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class Ejercicio7Activity extends Activity {

    EditText etPrecioBase;
    ToggleButton tbtnInstalacion, tbtnFormacion, tbtnAlimentacionBD;
    TextView tvPrecioInstalacion, tvPrecioFormacion, tvPrecioAlimentacionBD;
    Button btnCalcular, btnRegresar;
    TextView tvResultado;

    // Precios fijos
    private final double PRECIO_INSTALACION = 40.0;
    private final double PRECIO_FORMACION = 200.0;
    private final double PRECIO_ALIMENTACION_BD = 200.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio7);

        // Inicializar componentes
        etPrecioBase = findViewById(R.id.etPrecioBase);
        tbtnInstalacion = findViewById(R.id.tbtnInstalacion);
        tbtnFormacion = findViewById(R.id.tbtnFormacion);
        tbtnAlimentacionBD = findViewById(R.id.tbtnAlimentacionBD);
        tvPrecioInstalacion = findViewById(R.id.tvPrecioInstalacion);
        tvPrecioFormacion = findViewById(R.id.tvPrecioFormacion);
        tvPrecioAlimentacionBD = findViewById(R.id.tvPrecioAlimentacionBD);
        btnCalcular = findViewById(R.id.btnCalcular);
        btnRegresar = findViewById(R.id.btnRegresar);
        tvResultado = findViewById(R.id.tvResultado);


        tvPrecioInstalacion.setText(String.valueOf((int)PRECIO_INSTALACION));
        tvPrecioFormacion.setText(String.valueOf((int)PRECIO_FORMACION));
        tvPrecioAlimentacionBD.setText(String.valueOf((int)PRECIO_ALIMENTACION_BD));


        tbtnInstalacion.setChecked(true);


        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularPrecioTotal();
            }
        });


        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void calcularPrecioTotal() {
        try {
            // Obtener precio base
            String precioBaseStr = etPrecioBase.getText().toString().trim();
            if (precioBaseStr.isEmpty()) {
                Toast.makeText(this, "Por favor ingrese el precio base", Toast.LENGTH_SHORT).show();
                return;
            }

            double precioBase = Double.parseDouble(precioBaseStr);
            double total = precioBase;

            // Sumar servicios adicionales aqui para no perderme
            if (tbtnInstalacion.isChecked()) {
                total += PRECIO_INSTALACION;
            }

            if (tbtnFormacion.isChecked()) {
                total += PRECIO_FORMACION;
            }

            if (tbtnAlimentacionBD.isChecked()) {
                total += PRECIO_ALIMENTACION_BD;
            }

            // Mostrar resultado
            tvResultado.setText("Total: $" + String.format("%.2f", total));

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Por favor ingrese un precio válido", Toast.LENGTH_SHORT).show();
        }
    }
}