package com.example.loginapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class Ejercicio9Activity extends Activity {

    NumberPicker spiValor;
    TextView lblValor;
    Button btnRegresar;


    private final int VALOR_MINIMO = 0;
    private final int VALOR_MAXIMO = 10;
    private final int PASO = 2;
    private final int VALOR_INICIAL = 4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio9);


        spiValor = findViewById(R.id.spiValor);
        lblValor = findViewById(R.id.lblValor);
        btnRegresar = findViewById(R.id.btnRegresar);

        configurarNumberPicker();


        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void configurarNumberPicker() {

        String[] valores = new String[6]; // 6 valores en total
        for (int i = 0; i < valores.length; i++) {
            valores[i] = String.valueOf(VALOR_MINIMO + (i * PASO));
        }


        spiValor.setMinValue(0);
        spiValor.setMaxValue(valores.length - 1);
        spiValor.setDisplayedValues(valores);
        spiValor.setValue(VALOR_INICIAL / PASO); // Posición 2 = valor 4
        spiValor.setWrapSelectorWheel(false); // No permitir ciclo infinito

        // Mostrar valor inicial
        lblValor.setText("El valor es: " + VALOR_INICIAL);


        spiValor.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal) {

                int valorReal = VALOR_MINIMO + (newVal * PASO);


                lblValor.setText("El valor es: " + valorReal);
            }
        });
    }
}