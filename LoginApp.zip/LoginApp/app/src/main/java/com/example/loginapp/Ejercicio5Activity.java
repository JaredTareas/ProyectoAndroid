package com.example.loginapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

public class Ejercicio5Activity extends Activity {

    Spinner spinnerEstudiantes;
    TextView textViewResultado;
    Button btnCurso1, btnCurso2, btnVaciar, btnRegresar;

    String[] curso1 = {"Juan", "María", "Luis"};
    String[] curso2 = {"Ana", "Marta", "José"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio5);

        spinnerEstudiantes = findViewById(R.id.spinnerEstudiantes);
        textViewResultado = findViewById(R.id.textViewResultado);
        btnCurso1 = findViewById(R.id.btnCurso1);
        btnCurso2 = findViewById(R.id.btnCurso2);
        btnVaciar = findViewById(R.id.btnVaciar);
        btnRegresar = findViewById(R.id.btnRegresar);

        spinnerEstudiantes.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String nombre = parent.getItemAtPosition(position).toString();
                textViewResultado.setText("Seleccionado: " + nombre);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // No hacer nada
            }
        });

        btnCurso1.setOnClickListener(v -> cargarEstudiantes(curso1));
        btnCurso2.setOnClickListener(v -> cargarEstudiantes(curso2));

        btnVaciar.setOnClickListener(v -> {
            spinnerEstudiantes.setAdapter(null);
            textViewResultado.setText("Seleccionado: ");
        });

        btnRegresar.setOnClickListener(v -> finish());
    }

    private void cargarEstudiantes(String[] estudiantes) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                estudiantes
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerEstudiantes.setAdapter(adapter);
    }
}
