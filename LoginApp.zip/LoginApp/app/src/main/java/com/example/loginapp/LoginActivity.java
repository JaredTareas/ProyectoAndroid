package com.example.loginapp;
import android.app.Activity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;

public class LoginActivity extends Activity {

    private EditText emailEditText, passwordEditText;
    private Button loginButton;
    private final String VALID_PASSWORD = "tap*2025";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Inicializar las vistas
        emailEditText = findViewById(R.id.emailEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);

        // Configurar el listener del botón
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validarLogin();
            }
        });
    }

    private void validarLogin() {
        String email = emailEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString();


        boolean emailValido = Patterns.EMAIL_ADDRESS.matcher(email).matches();
        boolean passwordCorrecta = password.equals(VALID_PASSWORD);


        if (!emailValido && !passwordCorrecta) {
            mostrarMensaje("Correo y contraseña incorrectos");
        } else if (!emailValido) {
            mostrarMensaje("Formato de correo no válido");
        } else if (!passwordCorrecta) {
            mostrarMensaje("Contraseña incorrecta");
        } else {
            mostrarMensaje("¡Bienvenido! Login exitoso");
            // Aquí podrías navegar a otra Activity
             Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
    }

    private void mostrarMensaje(String mensaje) {
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show();
    }
}