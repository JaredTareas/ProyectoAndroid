package com.example.loginapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class Ejercicio8Activity extends Activity {

    SeekBar slDeslizador;
    TextView lbIValor;
    Button btnRegresar;
    View vistaVisualizacion;

    // Valores del slider
    private final int VALOR_MINIMO = 100;
    private final int VALOR_MAXIMO = 500;
    private final int VALOR_INICIAL = 400;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio8);


        slDeslizador = findViewById(R.id.slDeslizador);
        lbIValor = findViewById(R.id.lbIValor);
        btnRegresar = findViewById(R.id.btnRegresar);
        vistaVisualizacion = findViewById(R.id.vistaVisualizacion);


        configurarSeekBar();


        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void configurarSeekBar() {

        slDeslizador.setMax(VALOR_MAXIMO - VALOR_MINIMO);
        slDeslizador.setProgress(VALOR_INICIAL - VALOR_MINIMO);

        // Mostrar valor inicial
        lbIValor.setText(String.valueOf(VALOR_INICIAL));


        slDeslizador.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                int valorReal = VALOR_MINIMO + progress;
                lbIValor.setText(String.valueOf(valorReal));
                actualizarVisualizacion(valorReal);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


        slDeslizador.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, android.view.MotionEvent event) {
                if (event.getAction() == android.view.MotionEvent.ACTION_DOWN) {
                    SeekBar seekBar = (SeekBar) v;


                    int width = seekBar.getWidth() - seekBar.getPaddingLeft() - seekBar.getPaddingRight();
                    int thumbWidth = seekBar.getThumb().getIntrinsicWidth();
                    int available = width - thumbWidth;
                    int x = (int) event.getX() - seekBar.getPaddingLeft() - thumbWidth / 2;

                    if (available > 0) {
                        float scale = Math.max(0, Math.min(1, (float) x / available));
                        int progress = (int) (scale * seekBar.getMax());

                        // Ajustar a múltiplos de 40
                        int valorActual = VALOR_MINIMO + progress;
                        int valorBase = ((valorActual - VALOR_MINIMO) / 40) * 40 + VALOR_MINIMO;

                        int diferencia = valorActual - valorBase;
                        int valorFinal;
                        if (diferencia >= 20) {
                            valorFinal = Math.min(valorBase + 40, VALOR_MAXIMO);
                        } else {
                            valorFinal = valorBase;
                        }

                        seekBar.setProgress(valorFinal - VALOR_MINIMO);
                        return true;
                    }
                }
                return false;
            }
        });


        actualizarVisualizacion(VALOR_INICIAL);
    }

    private void actualizarVisualizacion(int valor) {

        float porcentaje = (float)(valor - VALOR_MINIMO) / (VALOR_MAXIMO - VALOR_MINIMO);


        int rojo = (int)(200 - (porcentaje * 150)); // De 200 a 50
        int verde = (int)(220 - (porcentaje * 100)); // De 220 a 120
        int azul = (int)(255 - (porcentaje * 50)); // De 255 a 205


        rojo = Math.max(0, Math.min(255, rojo));
        verde = Math.max(0, Math.min(255, verde));
        azul = Math.max(0, Math.min(255, azul));

        int color = android.graphics.Color.rgb(rojo, verde, azul);
        vistaVisualizacion.setBackgroundColor(color);
    }
}