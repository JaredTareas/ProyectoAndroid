package com.example.loginapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class Ejercicio10Activity extends Activity {

    SeekBar desValor;
    TextView lblValor;
    Button btnRegresar;
    Button btnMenos;
    Button btnMas;


    private final int VALOR_MINIMO = 50;
    private final int VALOR_MAXIMO = 145;
    private final int VALOR_INICIAL = 70;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio10);


        desValor = findViewById(R.id.desValor);
        lblValor = findViewById(R.id.lblValor);
        btnRegresar = findViewById(R.id.btnRegresar);
        btnMenos = findViewById(R.id.btnMenos);
        btnMas = findViewById(R.id.btnMas);


        configurarSeekBar();


        configurarBotones();


        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        desValor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int valorActual = VALOR_MINIMO + desValor.getProgress();
                int nuevoValor;


                nuevoValor = valorActual + 20;
                if (nuevoValor > VALOR_MAXIMO) {
                    nuevoValor = VALOR_MAXIMO;
                }

                desValor.setProgress(nuevoValor - VALOR_MINIMO);
                lblValor.setText("El valor es: " + nuevoValor);
            }
        });
    }

    private void configurarBotones() {

        btnMenos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int valorActual = VALOR_MINIMO + desValor.getProgress();
                int nuevoValor = valorActual - 2;

                if (nuevoValor < VALOR_MINIMO) {
                    nuevoValor = VALOR_MINIMO;
                }

                desValor.setProgress(nuevoValor - VALOR_MINIMO);
                lblValor.setText("El valor es: " + nuevoValor);
            }
        });


        btnMas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int valorActual = VALOR_MINIMO + desValor.getProgress();
                int nuevoValor = valorActual + 2;

                if (nuevoValor > VALOR_MAXIMO) {
                    nuevoValor = VALOR_MAXIMO;
                }

                desValor.setProgress(nuevoValor - VALOR_MINIMO);
                lblValor.setText("El valor es: " + nuevoValor);
            }
        });
    }

    private void configurarSeekBar() {

        desValor.setMax(VALOR_MAXIMO - VALOR_MINIMO); // 95 (145-50)
        desValor.setProgress(VALOR_INICIAL - VALOR_MINIMO); // 20 (70-50)


        lblValor.setText("El valor es: " + VALOR_INICIAL);


        desValor.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                int valorReal = VALOR_MINIMO + progress;


                lblValor.setText("El valor es: " + valorReal);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }
}