package com.example.loginapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.widget.Spinner;
import java.util.ArrayList;

public class EjercicioActivity extends Activity {


    private CheckBox checkBoxPerro, checkBoxGato, checkBoxRaton;


    private RadioGroup radioGroupColores;
    private RadioButton radioRojo, radioVerde, radioAzul;


    private android.widget.ListView listViewColores;


    private Spinner spinnerColores;


    private Button btnAceptar, btnRegresar;
    private TextView textViewResultado;

    private int ejercicioNumero;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        ejercicioNumero = getIntent().getIntExtra("ejercicio_numero", 1);

        if (ejercicioNumero == 1) {
            setContentView(R.layout.activity_ejercicio);
            setupEjercicio1();
        } else if (ejercicioNumero == 2) {
            setContentView(R.layout.activity_ejercicio2);
            setupEjercicio2();
        } else if (ejercicioNumero == 3) {
            setContentView(R.layout.activity_ejercicio3);
            setupEjercicio3();
        } else if (ejercicioNumero == 4) {
            setContentView(R.layout.activity_ejercicio4);
            setupEjercicio4();
        }
    }

    private void setupEjercicio1() {
        // Inicializar vistas para Ejercicio 1
        checkBoxPerro = findViewById(R.id.checkBoxPerro);
        checkBoxGato = findViewById(R.id.checkBoxGato);
        checkBoxRaton = findViewById(R.id.checkBoxRaton);
        btnAceptar = findViewById(R.id.btnAceptar);
        btnRegresar = findViewById(R.id.btnRegresar);
        textViewResultado = findViewById(R.id.textViewResultado);

        // Configurar el botón aceptar
        btnAceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                actualizarResultadoAnimales();
            }
        });

        // Configurar el botón regresar
        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Mostrar resultado inicial
        textViewResultado.setText("Animales elegidos: Ninguno");
    }

    private void setupEjercicio2() {
        // Inicializar vistas para Ejercicio 2
        radioGroupColores = findViewById(R.id.radioGroupColores);
        radioRojo = findViewById(R.id.radioRojo);
        radioVerde = findViewById(R.id.radioVerde);
        radioAzul = findViewById(R.id.radioAzul);
        btnAceptar = findViewById(R.id.btnAceptar);
        btnRegresar = findViewById(R.id.btnRegresar);
        textViewResultado = findViewById(R.id.textViewResultado);

        // Configurar el botón aceptar
        btnAceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                actualizarResultadoColores();
            }
        });

        // Configurar el botón regresar
        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Mostrar resultado inicial
        textViewResultado.setText("Color elegido: Ninguno");
    }

    private void setupEjercicio3() {
        // Inicializar vistas para Ejercicio 3
        listViewColores = findViewById(R.id.listViewColores);
        btnAceptar = findViewById(R.id.btnAceptar);
        btnRegresar = findViewById(R.id.btnRegresar);
        textViewResultado = findViewById(R.id.textViewResultado);

        // Crear lista de colores
        String[] colores = {"Rojo", "Verde", "Azul"};

        // Configurar el adaptador para la ListView
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_single_choice, colores);
        listViewColores.setAdapter(adapter);
        listViewColores.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

        // Configurar listener automático para ListView
        listViewColores.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String colorSeleccionado = (String) parent.getItemAtPosition(position);
                textViewResultado.setText("El color seleccionado es: " + colorSeleccionado);
            }
        });

        // Configurar el botón aceptar
        btnAceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int position = listViewColores.getCheckedItemPosition();
                if (position != ListView.INVALID_POSITION) {
                    String colorSeleccionado = (String) listViewColores.getItemAtPosition(position);
                    textViewResultado.setText("El color seleccionado es: " + colorSeleccionado);
                } else {
                    textViewResultado.setText("El color seleccionado es: Ninguno");
                }
            }
        });

        // Configurar el botón regresar
        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Mostrar resultado inicial
        textViewResultado.setText("El color seleccionado es: Ninguno");
    }

    private void setupEjercicio4() {
        // Inicializar vistas para Ejercicio 4
        spinnerColores = findViewById(R.id.spinnerColores);

        btnRegresar = findViewById(R.id.btnRegresar);
        textViewResultado = findViewById(R.id.textViewResultado);


        String[] colores = {"Selecciona un color", "Rojo", "Verde", "Azul"};


        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, colores);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerColores.setAdapter(adapter);


        spinnerColores.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position > 0) { // Solo mostrar resultado si no es la opción por defecto
                    String colorSeleccionado = (String) parent.getItemAtPosition(position);
                    textViewResultado.setText("Color seleccionado: " + colorSeleccionado);
                    textViewResultado.setVisibility(View.VISIBLE);
                } else {
                    textViewResultado.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                textViewResultado.setVisibility(View.GONE);
            }
        });


        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        textViewResultado.setVisibility(View.GONE);
    }

    private void actualizarResultadoAnimales() {
        ArrayList<String> animalesSeleccionados = new ArrayList<>();

        if (checkBoxPerro.isChecked()) {
            animalesSeleccionados.add("Perro");
        }
        if (checkBoxGato.isChecked()) {
            animalesSeleccionados.add("Gato");
        }
        if (checkBoxRaton.isChecked()) {
            animalesSeleccionados.add("Ratón");
        }

        String resultado = "Animales elegidos: ";
        if (animalesSeleccionados.isEmpty()) {
            resultado += "Ninguno";
        } else {
            for (int i = 0; i < animalesSeleccionados.size(); i++) {
                resultado += animalesSeleccionados.get(i);
                if (i < animalesSeleccionados.size() - 1) {
                    resultado += ", ";
                }
            }
        }

        textViewResultado.setText(resultado);
    }

    private void actualizarResultadoColores() {
        String colorSeleccionado = "Ninguno";

        int selectedId = radioGroupColores.getCheckedRadioButtonId();

        if (selectedId == R.id.radioRojo) {
            colorSeleccionado = "Rojo";
        } else if (selectedId == R.id.radioVerde) {
            colorSeleccionado = "Verde";
        } else if (selectedId == R.id.radioAzul) {
            colorSeleccionado = "Azul";
        }

        textViewResultado.setText("Color elegido: " + colorSeleccionado);

    }
}