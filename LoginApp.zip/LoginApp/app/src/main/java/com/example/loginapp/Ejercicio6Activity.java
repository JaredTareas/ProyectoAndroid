package com.example.loginapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class Ejercicio6Activity extends Activity {

    Spinner spinnerNumeros;
    TextView textViewResultado;
    Button btnPares, btnImpares, btnVaciar;

    Integer[] numerosPares = {2, 4, 6, 8, 10};
    Integer[] numerosImpares = {1, 3, 5, 7, 9};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio6);

        spinnerNumeros = findViewById(R.id.spinnerNumeros);
        textViewResultado = findViewById(R.id.textViewResultado);
        btnPares = findViewById(R.id.btnPares);
        btnImpares = findViewById(R.id.btnImpares);
        btnVaciar = findViewById(R.id.btnVaciar);

        btnPares.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cargarNumeros(numerosPares);
            }
        });

        btnImpares.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cargarNumeros(numerosImpares);
            }
        });

        btnVaciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spinnerNumeros.setAdapter(null);
                textViewResultado.setText("Número seleccionado: ");
            }
        });

        Button btnRegresar = findViewById(R.id.btnRegresar);
        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });



        spinnerNumeros.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Integer numero = (Integer) spinnerNumeros.getSelectedItem();
                textViewResultado.setText("Número seleccionado: " + numero);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                // nada
            }
        });
    }

    private void cargarNumeros(Integer[] numeros) {
        ArrayAdapter<Integer> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, numeros);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerNumeros.setAdapter(adapter);
    }
}
